<?php
require "conn.php";
$emp_ID = $_POST["employeeID"];
$emp_first_name = $_POST["employeeFirstName"];

$mysql_qry_emp = "select * from employee where employeeID like '$emp_ID' and employeeFirstName like '$emp_first_name';";

$result_emp = mysqli_query($conn,$mysql_qry_emp);

if(mysqli_num_rows($result_emp) > 0){
	echo "login success";
}

else {
	echo "login failed";
}

?>
