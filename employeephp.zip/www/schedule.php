<?php
require "conn.php";
$cleaner_ID = $_POST["cleanerID"];


$mysql_qry_cleaner = "select * from bungalow_clean BC, restaurant_clean RC where RC.cleanerID = BC.cleanerID and RC.cleanerID like '$cleaner_ID' and BC.cleanerID like '$cleaner_ID';";
$result_cleaner = mysqli_query($conn,$mysql_qry_cleaner);

	while($row = mysqli_fetch_array($result_cleaner)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>