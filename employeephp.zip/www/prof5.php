<?php
require "conn.php";
$cln_ID = $_POST["cleanerID"];
$cln_first_name = $_POST["cleanerFirstName"];

$mysql_qry_cln = "select * from cleaner where cleanerID like '$cln_ID' and cleanerFirstName like '$cln_first_name';";
$result_cln = mysqli_query($conn,$mysql_qry_cln);

	while($row = mysqli_fetch_array($result_cln)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>