<?php
require "conn.php";
$employee_ID = $_POST["employeeID"];


$mysql_qry_employee = "select * from rest_request where employeeID like '$employee_ID';";

$result_employee = mysqli_query($conn,$mysql_qry_employee);

	while($row = mysqli_fetch_array($result_employee)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>