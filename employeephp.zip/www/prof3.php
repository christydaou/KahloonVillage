<?php
require "conn.php";
$emp_ID = $_POST["employeeID"];
$emp_first_name = $_POST["employeeFirstName"];

$mysql_qry_emp = "select * from employee where employeeID like '$emp_ID' and employeeFirstName like '$emp_first_name';";
$result_emp = mysqli_query($conn,$mysql_qry_emp);

	while($row = mysqli_fetch_array($result_emp)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>