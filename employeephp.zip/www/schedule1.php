<?php
require "conn.php";
$technician_ID = $_POST["technicianID"];


$mysql_qry_technician = "select * from restaurant_sustain RS, bungalow_repair BR where RS.technicianID = BR.technicianID and RS.technicianID like '$technician_ID' and BR.technicianID like '$technician_ID';";

$result_technician = mysqli_query($conn,$mysql_qry_technician);

	while($row = mysqli_fetch_array($result_technician)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>