<?php
require "conn.php";
$val1 = $_POST["cleanerID"];
$val2 = $_POST["frontID"];
$val3 = $_POST["restID"];
$val4 = $_POST["cleanTime"];
$mysql_qry = "insert into restaurant_clean(cleanerID,frontID,restID,cleanTime) values ('$val1','$val2','$val3','$val4')";

if ($conn -> query($mysql_qry)=== TRUE){
	echo "insert successful";
}

else{
	echo "Error: " . $mysql_qry . "<br>" . $conn->error;
}

$conn ->close();
?>	

