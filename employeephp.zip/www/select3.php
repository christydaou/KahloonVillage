<?php
require "conn.php";
$val1 = $_POST["frontID"];
$val2 = $_POST["restID"];
$val3 = $_POST["employeeID"];
$val4 = $_POST["restRequestHrs"];
$mysql_qry = "insert into rest_request(restID,employeeID,frontID,restRequestHrs) values ('$val2','$val3','$val1','$val4')";

if ($conn -> query($mysql_qry)=== TRUE){
	echo "insert successful";
}

else{
	echo "Error: " . $mysql_qry . "<br>" . $conn->error;
}

$conn ->close();
?>	

