<?php
require "conn.php";
$cln_ID = $_POST["cleanerID"];
$cln_first_name = $_POST["cleanerFirstName"];

$mysql_qry_cln = "select * from cleaner where cleanerID like '$cln_ID' and cleanerFirstName like '$cln_first_name';";

$result_cln = mysqli_query($conn,$mysql_qry_cln);

if(mysqli_num_rows($result_cln) > 0){
	echo "login success";
}

else {
	echo "login failed";
}

?>
