<?php
require "conn.php";
$val1 = $_POST["frontID"];
$val2 = $_POST["bungalowID"];
$val3 = $_POST["cleanerID"];
$val4 = $_POST["wipeTime"];
$mysql_qry = "insert into bungalow_clean(cleanerID,frontID,bungaloID,wipeTime) values ('$val3','$val1','$val2','$val4')";

if ($conn -> query($mysql_qry)=== TRUE){
	echo "insert successful";
}

else{
	echo "Error: " . $mysql_qry . "<br>" . $conn->error;
}

$conn ->close();
?>	

