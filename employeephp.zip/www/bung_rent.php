<?php
require "conn.php";
$front_ID = $_POST["frontID"];

$mysql_qry_front = "select * from bungalow_rent where frontID like '$front_ID';";

$result_front = mysqli_query($conn,$mysql_qry_front);

	while($row = mysqli_fetch_array($result_front)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>