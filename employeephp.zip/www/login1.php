<?php
require "conn.php";
$front_ID = $_POST["frontID"];
$front_first_name = $_POST["frontFirstName"];

$mysql_qry_front = "select * from FRONTOFFICER where frontID like '$front_ID' and frontFirstName like '$front_first_name';";

$result_front = mysqli_query($conn,$mysql_qry_front);

if(mysqli_num_rows($result_front) > 0){
	echo "login success";
}

else {
	echo "login failed";
}

?>
