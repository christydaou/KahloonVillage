<?php
require "conn.php";
$tech_ID = $_POST["technicianID"];
$tech_first_name = $_POST["technicianFirstName"];

$mysql_qry_tech = "select * from maintenancepersonal where technicianID like '$tech_ID' and technicianFirstName like '$tech_first_name';";
$result_tech = mysqli_query($conn,$mysql_qry_tech);

	while($row = mysqli_fetch_array($result_tech)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>