<?php
require "conn.php";
$tech_ID = $_POST["technicianID"];
$tech_first_name = $_POST["technicianFirstName"];

$mysql_qry_tech = "select * from maintenancepersonal where technicianID like '$tech_ID' and technicianFirstName like '$tech_first_name';";

$result_tech = mysqli_query($conn,$mysql_qry_tech);

if(mysqli_num_rows($result_tech) > 0){
	echo "login success";
}

else {
	echo "login failed";
}

?>
