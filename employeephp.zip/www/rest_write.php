<?php
require "conn.php";
$val1 = $_POST["frontID"];
$val2 = $_POST["clientID"];
$val3 = $_POST["restID"];
$val4 = $_POST["tableZone"];
$val5 = $_POST["tablePlace"];
$val6 = $_POST["requestTime"];
$mysql_qry = "insert into requested_table values ('$val2','$val1','$val3','$val6','$val4','$val5')";

if ($conn -> query($mysql_qry)=== TRUE){
	echo "insert successful";
}

else{
	echo "Error: " . $mysql_qry . "<br>" . $conn->error;
}

$conn ->close();
?>	

