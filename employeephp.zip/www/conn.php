<?php
$db_name = "kahloon1";
$mysql_username = "root";
$mysql_password = "root123";
$server_name = "localhost";
$conn = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);

?>