<?php
require "conn.php";
$front_ID = $_POST["frontID"];
$front_first_name = $_POST["frontFirstName"];

$mysql_qry_front = "select * from frontofficer where frontID like '$front_ID' and frontFirstName like '$front_first_name';";
$result_front = mysqli_query($conn,$mysql_qry_front);

	while($row = mysqli_fetch_array($result_front)){
			$data[] = $row ;
			
	}
	
print(json_encode($data,JSON_PRETTY_PRINT));


?>