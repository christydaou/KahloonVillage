<?php
require "conn.php";
$val1 = $_POST["frontID"];
$val2 = $_POST["restID"];
$val3 = $_POST["technicianID"];
$val4 = $_POST["sustainTime"];
$mysql_qry = "insert into restaurant_sustain(restID,frontID,technicianID,sustainTime) values ('$val2','$val1','$val3','$val4')";

if ($conn -> query($mysql_qry)=== TRUE){
	echo "insert successful";
}

else{
	echo "Error: " . $mysql_qry . "<br>" . $conn->error;
}

$conn ->close();
?>	

